const firebaseConfig = {
    apiKey: "AIzaSyDSH4bzGKkYnYmakEQm4_O4XV_oXkaJ8OA",
    authDomain: "jsappsskeleton.firebaseapp.com",
    databaseURL: "https://jsappsskeleton.firebaseio.com",
    projectId: "jsappsskeleton",
    storageBucket: "jsappsskeleton.appspot.com",
    messagingSenderId: "897375741010",
    appId: "1:897375741010:web:c2040738f22de117e1ab8b"
};

firebase.initializeApp(firebaseConfig);