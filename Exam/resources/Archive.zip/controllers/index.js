import user from './user.js';
import home from './home.js';
import article from './article.js';

export default {
    user, 
    home, 
    article,
};